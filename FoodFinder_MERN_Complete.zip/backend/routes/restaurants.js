import express from "express";
import Restaurant from "../models/Restaurant.js";
import {protect,adminOnly} from "../middleware/auth.js";
const router=express.Router();
router.get("/",async(req,res)=>{
 const q=req.query.search||"";const re=new RegExp(q,"i");
 res.json(await Restaurant.find({$or:[{name:re},{cuisine:re},{location:re}]}).sort({createdAt:-1}));
});
router.get("/:id",async(req,res)=>{try{res.json(await Restaurant.findById(req.params.id));}catch(e){res.status(404).json({message:"Restaurant not found"});}});
router.post("/",protect,adminOnly,async(req,res)=>{try{res.status(201).json(await Restaurant.create(req.body));}catch(e){res.status(400).json({message:e.message});}});
router.put("/:id",protect,adminOnly,async(req,res)=>{try{res.json(await Restaurant.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true}));}catch(e){res.status(400).json({message:e.message});}});
router.delete("/:id",protect,adminOnly,async(req,res)=>{await Restaurant.findByIdAndDelete(req.params.id);res.json({message:"Restaurant deleted"});});
export default router;
