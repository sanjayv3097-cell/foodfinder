import express from "express";
import Recipe from "../models/Recipe.js";
import {protect} from "../middleware/auth.js";
const router=express.Router();
router.get("/",async(req,res)=>{
 const q=req.query.search||"";const re=new RegExp(q,"i");
 res.json(await Recipe.find({$or:[{title:re},{category:re}]}).populate("author","name email").sort({createdAt:-1}));
});
router.get("/:id",async(req,res)=>{try{res.json(await Recipe.findById(req.params.id).populate("author","name email"));}catch(e){res.status(404).json({message:"Recipe not found"});}});
router.post("/",protect,async(req,res)=>{
 try{const r=await Recipe.create({...req.body,author:req.user._id});res.status(201).json(await r.populate("author","name email"));}
 catch(e){res.status(400).json({message:e.message});}
});
router.put("/:id",protect,async(req,res)=>{
 try{
  const r=await Recipe.findById(req.params.id);if(!r)return res.status(404).json({message:"Recipe not found"});
  if(String(r.author)!==String(req.user._id)&&req.user.role!=="admin")return res.status(403).json({message:"Not allowed"});
  Object.assign(r,req.body);await r.save();res.json(await r.populate("author","name email"));
 }catch(e){res.status(400).json({message:e.message});}
});
router.delete("/:id",protect,async(req,res)=>{
 const r=await Recipe.findById(req.params.id);if(!r)return res.status(404).json({message:"Recipe not found"});
 if(String(r.author)!==String(req.user._id)&&req.user.role!=="admin")return res.status(403).json({message:"Not allowed"});
 await r.deleteOne();res.json({message:"Recipe deleted"});
});
router.post("/:id/like",protect,async(req,res)=>{
 const r=await Recipe.findById(req.params.id);if(!r)return res.status(404).json({message:"Recipe not found"});
 const i=r.likes.findIndex(x=>String(x)===String(req.user._id));if(i>=0)r.likes.splice(i,1);else r.likes.push(req.user._id);
 await r.save();res.json({likes:r.likes.length});
});
export default router;
