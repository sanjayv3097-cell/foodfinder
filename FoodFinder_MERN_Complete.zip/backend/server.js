import express from "express";import cors from "cors";import dotenv from "dotenv";dotenv.config();
import connectDB from "./config/db.js";import auth from "./routes/auth.js";import restaurants from "./routes/restaurants.js";import recipes from "./routes/recipes.js";import admin from "./routes/admin.js";
await connectDB();const app=express();app.use(cors());app.use(express.json());
app.get("/",(req,res)=>res.json({message:"FoodFinder API running"}));app.get("/api/health",(req,res)=>res.json({status:"ok"}));
app.use("/api/auth",auth);app.use("/api/restaurants",restaurants);app.use("/api/recipes",recipes);app.use("/api/admin",admin);
app.listen(process.env.PORT||5000,()=>console.log("FoodFinder backend running on http://localhost:5000"));
