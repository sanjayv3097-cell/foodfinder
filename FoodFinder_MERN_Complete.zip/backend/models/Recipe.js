import mongoose from "mongoose";
const schema=new mongoose.Schema({
 title:{type:String,required:true}, category:{type:String,default:"Other"},
 ingredients:[String], instructions:{type:String,required:true},
 cookingTime:{type:Number,default:30}, servings:{type:Number,default:2},
 author:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
 image:{type:String,default:""},
 videoUrl:{type:String,default:""},
 likes:[{type:mongoose.Schema.Types.ObjectId,ref:"User"}]
},{timestamps:true});
export default mongoose.model("Recipe",schema);
