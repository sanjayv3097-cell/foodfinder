import mongoose from "mongoose";
const schema=new mongoose.Schema({
 name:{type:String,required:true}, cuisine:{type:String,required:true},
 location:{type:String,required:true}, address:{type:String,required:true},
 rating:{type:Number,default:4,min:0,max:5},
 openingHours:{type:String,default:"10:00 AM - 10:00 PM"},
 description:{type:String,default:""}, image:{type:String,default:""}
},{timestamps:true});
export default mongoose.model("Restaurant",schema);
