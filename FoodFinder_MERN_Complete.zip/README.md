# FoodFinder – MERN Restaurant Finder and Recipe Sharing Website

## Features
- React + Vite frontend
- Node.js + Express backend
- MongoDB + Mongoose
- JWT authentication and bcrypt password hashing
- Restaurant search by name, cuisine, and location
- Admin add/edit/delete restaurants
- Recipe search and details
- Add, edit, delete and like recipes
- Recipe image and YouTube video URL
- Admin dashboard and user management
- Sample restaurants and recipes

## Requirements
Node.js 18+ and MongoDB 7/8 or MongoDB Atlas.

## Windows setup

### Backend
Open Command Prompt:
```bat
cd backend
npm install
copy .env.example .env
npm run seed
npm run dev
```
Backend: http://localhost:5000

### Frontend
Open a second Command Prompt:
```bat
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

## Demo accounts
Admin:
admin@foodfinder.com
Admin@123

User:
sanjay@foodfinder.com
User@123

## Recipe video
When adding a recipe, enter a YouTube embed URL, for example:
https://www.youtube.com/embed/VIDEO_ID
